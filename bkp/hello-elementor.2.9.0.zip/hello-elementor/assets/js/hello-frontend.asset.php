<?php return array('dependencies' => array(), 'version' => '63da6b83b71bcd94feac');
