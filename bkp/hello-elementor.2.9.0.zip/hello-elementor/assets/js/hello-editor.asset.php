<?php return array('dependencies' => array(), 'version' => 'd0e721020bdc2dd0855c');
